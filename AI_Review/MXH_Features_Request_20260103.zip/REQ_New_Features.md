# Yêu cầu tính năng mới cho MXH Dashboard

## 1. Tab "Tất cả" chuyển thành Dropdown Menu
- **Hiện tại:** Các tab "Tất cả", "WeChat" đang nằm ngang hàng.
- **Yêu cầu mới:**
  - Tab "Tất cả" sẽ trở thành một **Dropdown Menu**.
  - Bên trong Dropdown này sẽ chứa các mục con (ví dụ: WeChat).
  - Mặc định: Ưu tiên hiển thị tab **WeChat** lên đầu hoặc chọn mặc định là WeChat (vì WeChat quan trọng nhất).
  - **Hành vi:** Khi click vào một mục trong dropdown (ví dụ WeChat), thực hiện lọc hiển thị chỉ các account thuộc platform đó.

## 2. Thêm Panel Thống Kê (Statistics Panel)
- **Vị trí:** Thêm 2 hộp/panel hiển thị thông số ở khu vực hợp lý (ví dụ dưới thanh toolbar hoặc trên grid).
- **Dữ liệu hiển thị:** Thống kê theo tab đang chọn (ví dụ WeChat).
- **Format hiển thị:**
  ```text
  Tài khoản: [Tổng số] | TK 1 năm: [Số lượng >1 năm] | TK mới: [Số lượng <1 tháng] | TK hạn chế: [Số lượng Disabled]
  ```
- **Ví dụ cụ thể:**
  - "Tài khoản: 100" (Tổng account)
  - "TK 1 năm: 10" (Account tạo > 1 năm)
  - "TK mới: 5" (Account mới tạo trong tháng)
  - "TK hạn chế: [Số lượng]" (Account bị vô hiệu hóa/die)

## 3. Cải tiến UX bộ lọc (Filter Visualization)
- **Hiện tại:** Khi lọc (theo trạng thái, ngày tháng...), các card không thỏa mãn điều kiện sẽ bị **ẩn đi** (`display: none`).
- **Yêu cầu mới:**
  - **KHÔNG ẩn** các card không thỏa mãn.
  - **Hiển thị mờ (Dimmed):** Các card không thỏa mãn sẽ chuyển sang màu tối (đen/xám mờ).
  - **Visual Cue:** Hiển thị thêm biểu tượng chữ **"X"** màu xám hoặc chữ **"None"** đè lên card để báo hiệu card này bị loại bởi bộ lọc.
  - Mục đích: Giữ nguyên layout grid, người dùng vẫn thấy tổng quan nhưng biết card nào đang được lọc.

---

## Technical Context
- Codebase: Python Flask (backend) + Vanilla JS (frontend).
- File giao diện chính: `app/templates/mxh.html`.
- Dữ liệu accounts: Biến global `mxhAccounts` (JavaScript Array).
- Styling: Sử dụng CSS trong `mxh.html` (chưa có file css riêng).
